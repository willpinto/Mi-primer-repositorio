﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pasar_una_frase_a_un_arreglo
{
    class Program
    {
        public static string Mid(string param, int startIndex, int length)
        {
            string result = param.Substring(startIndex, length);
            return result;
        }
        static void Main(string[] args)
        {
            string CAD;
            int POS = 0;
            int LEN = 0;
            Console.Write("DIGITE UNA FRASE:");
            CAD = Console.ReadLine();
            LEN = CAD.Length;
            string[] VEC = new string[LEN + 1];
            // PASAMOS CARACTER A CARACTER AL ARREGLO
            for (POS = 1; POS <= LEN; POS++)
            {
                VEC[POS] = Mid(CAD, POS - 1, 1);
            }
            // SALIDA
            for (POS = 1; POS <= LEN; POS++)
            {
                Console.WriteLine(VEC[POS]);
            }
            Console.Write("Pulse una Tecla:");
            Console.ReadLine();

        }
    }
}
